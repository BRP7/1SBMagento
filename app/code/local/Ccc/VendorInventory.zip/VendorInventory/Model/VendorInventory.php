<?php
class Ccc_VendorInventory_Model_Banner extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        // echo 123;
        $this->_init('ccc_VendorInventory/VendorInventory');
    }

}

?>

