<?php
class Ccc_VendorInventory_Helper_Banner extends Mage_Core_Helper_Abstract
{

}
?>