<?php
class Ccc_Banner_Helper_Banner extends Mage_Core_Helper_Abstract
{

}
?>