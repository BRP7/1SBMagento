<?php

class Ccc_Outlook_Model_Dispatchevent extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('ccc_outlook/dispatchevent');
    }
}