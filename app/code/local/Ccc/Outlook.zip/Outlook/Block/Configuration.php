<?php

class Ccc_Outlook_Block_Configuration extends Mage_Catalog_Block_Product_Abstract{

}